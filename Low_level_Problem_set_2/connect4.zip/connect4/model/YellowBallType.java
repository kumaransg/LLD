package connect4.model;

import connect4.constants.BallColor;

/**
 * @author priyamvora
 * @created 15/05/2021
 */
public class YellowBallType extends BallType {

    public YellowBallType() {
        super(BallColor.YELLOW);
    }
}
