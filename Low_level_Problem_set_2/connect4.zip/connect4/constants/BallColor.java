package connect4.constants;

/**
 * @author priyamvora
 * @created 15/05/2021
 */
public enum BallColor {
    RED,
    YELLOW
}
