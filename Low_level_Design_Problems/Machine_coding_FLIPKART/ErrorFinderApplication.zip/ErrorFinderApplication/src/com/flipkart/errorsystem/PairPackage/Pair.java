package com.flipkart.errorsystem.PairPackage;

public class Pair {

	public char first;
	public char second;
	public Pair(char c,char d)
	{
		this.first=c;
		this.second=d;
	}
}
