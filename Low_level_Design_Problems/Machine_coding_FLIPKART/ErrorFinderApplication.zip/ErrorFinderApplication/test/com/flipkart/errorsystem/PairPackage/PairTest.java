//package com.flipkart.errorsystem.PairPackage;
//
//public class PairTest {
//
//	public char first;
//	public char second;
//	public PairTest(char c,char d)
//	{
//		this.first=c;
//		this.second=d;
//	}
//}
