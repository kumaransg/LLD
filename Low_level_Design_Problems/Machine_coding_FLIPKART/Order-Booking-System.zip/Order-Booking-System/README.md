# Simple-Order-Booking-System

Best Selling Price:::

The following program performs the following functions much like an ecommerce website.

1.) You can add a product -> addProduct(“p1″) 

2.) A user can purchase a product -> purchase(“u1″,”p1″) 

3.) A user can return a product -> returnProduct(“u1″,”p1″) 

4.) A user can be blacklisted and all of his purchases will be marked null -> blackListUser(“u1″) 

5.) Display the best selling product -> bestSelling() Best selling product will be the one which have been bought by most number of unique users.  

6.) Display the best selling products for each category.
