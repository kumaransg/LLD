package test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import application.mainClass;;

public class MainClassTest {
	@Test
	public void secondclasstest() throws Exception
	{
		mainClass obj=new mainClass();
		//assertNotNull(obj.name);
	}
}
