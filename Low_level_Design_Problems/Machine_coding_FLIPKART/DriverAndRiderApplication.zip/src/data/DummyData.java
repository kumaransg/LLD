package data;

public class DummyData {
	
	public static String dataArray[][]= {
										{"d1","4","c1","5"},
										{"d1","5","c2","4"},
										{"d1","1","c3","2"},
										{"d2","5","c1","1"},
										{"d2","5","c2","5"},
										{"d2","4","c3","5"},
										{"d3","3","c1","2"},
										{"d3","4","c2","5"},
										{"d3","3","c3","3"}
										};
}
