package input;

public class datainput {

	
	void takeInput() 
	{
		System.out.println("Please enter new entries");
	}
	void dataAccess() 
	{
		
	}
}
