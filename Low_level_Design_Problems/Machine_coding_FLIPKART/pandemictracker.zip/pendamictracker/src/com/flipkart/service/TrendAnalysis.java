package com.flipkart.service;

public class TrendAnalysis {
	TrendAnalysis trendAnalysis = new TrendAnalysis();
		void getTrend(String factor) {
			switch(factor) {
			case "weekly": trendAnalysis.getWeeklyTrend();
			}
		}
	private void getWeeklyTrend() {
		
	}
	private void getMonthlyTrend() {
		
	}
	private void getYearlyTrend() {
		
	}
}
