package com.filpkart.TextpadApplication;

public class Main {

	public static void main(String[] args) 
	{
		TextPadAppClass textpadApplicationObject = new TextPadAppClass();
		textpadApplicationObject.driver();
				
	}
	
}
