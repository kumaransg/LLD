1. The changes are done in MVC manner (keeping in mind of spring boot).
2. HomeService is main service class.
3. Interest of time, autowiring is not done. So dao instation in service has to be done through constructor.
4. Code formatting, clean code etc could not be done in interst of time.