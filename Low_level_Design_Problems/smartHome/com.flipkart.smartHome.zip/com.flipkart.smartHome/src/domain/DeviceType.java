package domain;

public enum DeviceType {

    GOOGLE, // device id is 1 for google.
    ALEXA; // device id is 2 for Alexa.
}
