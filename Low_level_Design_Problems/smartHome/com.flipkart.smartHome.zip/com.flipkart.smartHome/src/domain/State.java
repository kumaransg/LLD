package domain;

public enum State {
    SPEED,
    BRIGHTNESS;
}
