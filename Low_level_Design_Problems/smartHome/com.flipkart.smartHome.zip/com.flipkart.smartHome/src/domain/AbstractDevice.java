package domain;

public abstract class AbstractDevice {
}
