package domain;

public enum SmartHomeDeviceCategory {
    LIVING_ROOM_LIGHT,
    DRAWING_ROOM_LIGHT,
    SMART_CHARGER,
    LIVING_ROOM_FAN,
    DRAWING_ROOM_FAN;
}
