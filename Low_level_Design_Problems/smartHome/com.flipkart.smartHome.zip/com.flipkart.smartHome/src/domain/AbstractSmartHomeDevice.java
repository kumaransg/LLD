package domain;

public abstract class AbstractSmartHomeDevice {
}
