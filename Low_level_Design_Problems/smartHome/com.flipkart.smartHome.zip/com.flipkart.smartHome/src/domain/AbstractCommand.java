package domain;

public abstract class AbstractCommand {
}
