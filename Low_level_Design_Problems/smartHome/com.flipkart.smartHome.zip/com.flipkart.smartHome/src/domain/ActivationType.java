package domain;

public enum ActivationType {

    OK_GOOGLE,
    ALEXA;
}
